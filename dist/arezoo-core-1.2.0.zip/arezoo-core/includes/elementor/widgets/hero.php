<?php
/**
 * «صحنهٔ هیرو آرزو» — a living background for a hero container.
 * Put it first inside a container and it fills that container behind the other widgets,
 * so the title, text and buttons stay ordinary, separately editable Elementor widgets.
 *
 * Four kinds of scene: one picture with moving regions, separate layers, your own video,
 * or a slideshow.
 *
 * @package ArezooCore
 */

namespace Arezoo\Widgets;

use Elementor\Controls_Manager as CM;
use Elementor\Repeater;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Hero extends Base {

	public function get_name() {
		return 'ay-hero';
	}

	public function get_title() {
		return 'صحنهٔ هیرو آرزو';
	}

	public function get_icon() {
		return 'eicon-image-rollover';
	}

	public function get_script_depends(): array {
		return array( 'arezoo-hero', 'arezoo' );
	}

	/** The motion set-up made for the bundled «باغ شب» picture (all values in percent of the picture). */
	public static function night_regions() {
		$r = function ( $label, $x, $y, $w, $h, $feather, $type, $amp, $speed, $px, $py, $phase, $depth, $for = 'wide' ) {
			return array( 'label' => $label, 'on' => 'yes', 'for' => $for, 'x' => array( 'size' => $x, 'unit' => '%' ), 'y' => array( 'size' => $y, 'unit' => '%' ), 'w' => array( 'size' => $w, 'unit' => '%' ), 'h' => array( 'size' => $h, 'unit' => '%' ), 'feather' => array( 'size' => $feather ), 'type' => $type, 'amp' => array( 'size' => $amp ), 'speed' => array( 'size' => $speed ), 'px' => array( 'size' => $px, 'unit' => '%' ), 'py' => array( 'size' => $py, 'unit' => '%' ), 'phase' => array( 'size' => $phase ), 'depth' => array( 'size' => $depth ) );
		};
		return array(
			$r( 'قاصدک و ساقه', 21.5, 56, 34, 80, 55, 'sway', 28, 0.55, 13.5, 93, 0, 0.6 ),
			$r( 'کرک قاصدک', 24.5, 42, 24, 40, 80, 'wave', 16, 1.1, 24.5, 42, 0, 0.3 ),
			$r( 'دانهٔ بالا چپ', 10, 31, 10, 17, 70, 'wave', 30, 0.8, 10, 31, 0, 1.2 ),
			$r( 'دانهٔ چپ', 4.5, 42, 10, 18, 70, 'wave', 30, 0.7, 4.5, 42, 1.4, 1.2 ),
			$r( 'دانهٔ راست قاصدک', 39, 40.5, 8, 12, 70, 'wave', 30, 0.9, 39, 40.5, 2.6, 1.2 ),
			$r( 'دانهٔ پایین', 37.5, 58.5, 9, 11, 70, 'wave', 30, 0.75, 37.5, 58.5, 4, 1.2 ),
			$r( 'شاخهٔ چپ', 33.5, 16.5, 30, 32, 60, 'sway', 24, 0.45, 50, 12, 1, 0.4 ),
			$r( 'برگ و غنچهٔ بالا', 44.5, 5, 10, 16, 60, 'sway', 20, 0.5, 49, 10, 2.2, 0.4 ),
			$r( 'برگ‌های راست', 90, 20, 14, 28, 60, 'sway', 28, 0.5, 88, 11, 2, 0.4 ),
			$r( 'غنچه‌های راست', 90, 5, 10, 12, 70, 'wave', 15, 0.9, 90, 5, 0, 0.3 ),
			$r( 'گل پایین چپ', 24, 74, 22, 28, 60, 'sway', 24, 0.5, 22.5, 90, 0.6, 0.8 ),
			$r( 'برگ‌های پایین چپ', 39, 84, 20, 26, 60, 'sway', 20, 0.4, 31, 93, 3, 0.9 ),
			$r( 'برگ‌های پایین راست', 81, 84, 15, 26, 60, 'sway', 20, 0.42, 86, 93, 1.5, 0.9 ),
			$r( 'گل پایین راست', 92.5, 72, 15, 30, 60, 'sway', 24, 0.48, 93, 90, 2.2, 0.8 ),
			$r( 'گردنبند', 62, 50, 38, 92, 35, 'sway', 9, 0.38, 63, 8, 0, 0.9 ),
			/* the 4:3 picture (tablets, near-square frames) */
			$r( 'تبلت · قاصدک و ساقه', 12, 58, 30, 80, 55, 'sway', 26, 0.55, 1, 77, 0, 0.6, 'tablet' ),
			$r( 'تبلت · کرک قاصدک', 13, 42, 30, 36, 80, 'wave', 16, 1.1, 13, 42, 0, 0.3, 'tablet' ),
			$r( 'تبلت · دانهٔ بالا', 33, 38, 9, 9, 70, 'wave', 30, 0.9, 33, 38, 2.6, 1.2, 'tablet' ),
			$r( 'تبلت · دانهٔ پایین', 30, 59, 11, 9, 70, 'wave', 30, 0.75, 30, 59, 4, 1.2, 'tablet' ),
			$r( 'تبلت · شاخهٔ چپ', 27, 14, 44, 26, 60, 'sway', 22, 0.45, 48, 8, 1, 0.4, 'tablet' ),
			$r( 'تبلت · برگ‌های راست', 97, 17, 10, 26, 60, 'sway', 26, 0.5, 95, 10, 2, 0.4, 'tablet' ),
			$r( 'تبلت · غنچه‌های راست', 97, 6, 9, 9, 70, 'wave', 15, 0.9, 97, 6, 0, 0.3, 'tablet' ),
			$r( 'تبلت · گل پایین چپ', 14, 73, 24, 22, 60, 'sway', 24, 0.5, 11, 82, 0.6, 0.8, 'tablet' ),
			$r( 'تبلت · برگ‌های پایین چپ', 30, 85, 34, 28, 60, 'sway', 18, 0.4, 20, 93, 3, 0.9, 'tablet' ),
			$r( 'تبلت · برگ‌های پایین راست', 88, 85, 26, 28, 60, 'sway', 18, 0.42, 97, 92, 1.5, 0.9, 'tablet' ),
			$r( 'تبلت · گردنبند', 63, 47, 52, 92, 35, 'sway', 8, 0.38, 63, 5, 0, 0.9, 'tablet' ),
			/* the tall picture (phones, upright frames) */
			$r( 'موبایل · گردنبند', 69, 37, 66, 42, 35, 'sway', 7, 0.38, 69, 19, 0, 0.9, 'mobile' ),
			$r( 'موبایل · شاخه و برگ‌های بالا', 82, 14, 40, 13, 60, 'sway', 20, 0.45, 100, 18, 1, 0.4, 'mobile' ),
			$r( 'موبایل · برگ‌های چپ', 34, 26, 20, 8, 60, 'sway', 22, 0.5, 45, 22, 2, 0.4, 'mobile' ),
			$r( 'موبایل · قاصدک و ساقه', 87, 80, 22, 26, 55, 'sway', 22, 0.55, 84, 95, 0, 0.6, 'mobile' ),
			$r( 'موبایل · کرک قاصدک', 88, 73, 24, 10, 80, 'wave', 14, 1.1, 88, 73, 0, 0.3, 'mobile' ),
			$r( 'موبایل · دانه‌ها', 70, 75, 18, 10, 70, 'wave', 28, 0.8, 70, 75, 1.4, 1.2, 'mobile' ),
			$r( 'موبایل · گل پایین', 68, 85, 18, 8, 60, 'sway', 22, 0.5, 70, 90, 0.6, 0.8, 'mobile' ),
			$r( 'موبایل · برگ‌های پایین', 45, 95, 62, 10, 60, 'sway', 16, 0.4, 50, 100, 3, 0.9, 'mobile' ),
		);
	}

	public static function night_sparks() {
		$out = array();
		foreach ( array( array( 1010, 585, 1.4, 4.2, 0 ), array( 892, 738, 1.1, 5, 1.7 ), array( 1000, 745, 1, 4.6, 3.1 ), array( 1190, 765, 1.3, 5.4, 0.8 ), array( 805, 470, 0.9, 6, 2.4 ), array( 1075, 735, 1.2, 4.4, 3.8 ), array( 955, 672, 0.9, 5.2, 1.1 ), array( 1188, 660, 0.8, 6.2, 4.4 ), array( 1262, 500, 0.8, 5.6, 2.9 ), array( 760, 318, 0.6, 6.6, 0.4 ), array( 1345, 318, 0.6, 7, 3.5 ) ) as $p ) {
			$out[] = array( 'for' => 'wide', 'x' => array( 'size' => round( $p[0] / 16.72, 2 ), 'unit' => '%' ), 'y' => array( 'size' => round( $p[1] / 9.41, 2 ), 'unit' => '%' ), 'size' => array( 'size' => $p[2] ), 'dur' => array( 'size' => $p[3] ), 'delay' => array( 'size' => $p[4] ) );
		}
		foreach ( array( 'tablet' => array( array( 56, 69 ), array( 65, 75 ), array( 73.5, 67 ), array( 52, 52 ), array( 78, 50 ), array( 61, 60 ), array( 69, 82 ) ), 'mobile' => array( array( 60, 47 ), array( 72, 51 ), array( 83, 45 ), array( 52, 42 ), array( 88, 40 ), array( 63, 53 ), array( 77, 55 ) ) ) as $for => $pts ) {
			foreach ( $pts as $i => $p ) {
				$out[] = array( 'for' => $for, 'x' => array( 'size' => $p[0], 'unit' => '%' ), 'y' => array( 'size' => $p[1], 'unit' => '%' ), 'size' => array( 'size' => 'mobile' === $for ? 2.4 - ( $i % 3 ) * 0.4 : 1.3 - ( $i % 3 ) * 0.2 ), 'dur' => array( 'size' => 4.2 + ( $i % 4 ) * 0.6 ), 'delay' => array( 'size' => $i * 0.7 ) );
			}
		}
		return $out;
	}

	public static function night_floats() {
		$out = array();
		foreach ( array( array( 'a', 24, 30, 6.5, 38, -22, 50, 34, 0 ), array( 'c', 30, 40, 5.5, 45, -8, -40, 42, 12 ), array( 'd', 22, 48, 7, 52, 10, 70, 38, 22 ), array( 'b', 18, 24, 7.5, 30, -30, -60, 46, 30 ), array( 'c', 28, 36, 4.5, 60, -16, 90, 52, 40 ) ) as $f ) {
			$out[] = array( 'image' => array( 'url' => ay_asset( 'img/hero/seed-' . $f[0] . '.png' ) ), 'x' => array( 'size' => $f[1], 'unit' => '%' ), 'y' => array( 'size' => $f[2], 'unit' => '%' ), 'w' => array( 'size' => $f[3], 'unit' => '%' ), 'dx' => array( 'size' => $f[4] ), 'dy' => array( 'size' => $f[5] ), 'rot' => array( 'size' => $f[6] ), 'dur' => array( 'size' => $f[7] ), 'delay' => array( 'size' => $f[8] ), 'opacity' => array( 'size' => 0.85 ) );
		}
		return $out;
	}

	/** The bundled pictures come in several sizes; the right one is picked for the screen. [ family => [ [ file, width, height ] … ] ] */
	public static function families() {
		return array(
			'wide'   => array( array( 'hero-lg.webp', 2560, 1440 ), array( 'hero-xl.webp', 3200, 1800 ) ),
			'tablet' => array( array( 'hero-tablet-sm.webp', 1680, 1260 ), array( 'hero-tablet-md.webp', 2048, 1536 ), array( 'hero-tablet-lg.webp', 2560, 1920 ) ),
			'mobile' => array( array( 'hero-mobile-xs.webp', 720, 1560 ), array( 'hero-mobile-sm.webp', 960, 2080 ), array( 'hero-mobile-md.webp', 1536, 3328 ) ),
		);
	}

	public static function family_default( $family ) {
		$f = array( 'wide' => 'hero-lg.webp', 'tablet' => 'hero-tablet-md.webp', 'mobile' => 'hero-mobile-sm.webp' );
		return 'img/hero/' . $f[ $family ];
	}

	/** [ sizes, width, height ] of one picture setting; bundled pictures bring all their sizes. */
	private function variant_source( $media ) {
		$url = isset( $media['url'] ) ? (string) $media['url'] : '';
		if ( '' === $url ) {
			return null;
		}
		$id  = isset( $media['id'] ) ? absint( $media['id'] ) : 0;
		$rel = $id ? (string) get_post_meta( $id, '_ay_asset', true ) : '';
		$key = $rel ? basename( $rel ) : basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		if ( false !== strpos( $key, 'night-garden' ) ) {
			$key = 'hero-lg.webp';   /* the first bundled picture: same artwork, now in full quality */
		}
		foreach ( self::families() as $files ) {
			foreach ( $files as $f ) {
				if ( $f[0] === $key ) {
					$set = array();
					foreach ( $files as $g ) {
						$set[] = array( ay_asset( 'img/hero/' . $g[0] ), $g[1] );
					}
					return array( $set, $f[1], $f[2], true );
				}
			}
		}
		list( $w, $h ) = $this->media_dims( $media );
		return array( array( array( esc_url_raw( $url ), $w ) ), $w, $h );
	}

	private function rs( Repeater $rep, $id, $label, $min, $max, $step, $default, $unit = '' ) {
		$u = '' === $unit ? 'px' : $unit;
		$rep->add_control( $id, array( 'label' => $label, 'type' => CM::SLIDER, 'size_units' => array( $u ), 'range' => array( $u => array( 'min' => $min, 'max' => $max, 'step' => $step ) ), 'default' => array( 'unit' => $u, 'size' => $default ) ) );
	}

	protected function register_controls() {
		$regions = array( 'mode' => 'regions' );
		$layers  = array( 'mode' => 'layers' );
		$video   = array( 'mode' => 'video' );
		$slides  = array( 'mode' => 'slideshow' );

		/* ---- scene ---- */
		$this->sec( 's_scene', 'صحنه' );
		$this->sel( 'mode', 'نوع صحنه', array( 'regions' => 'یک عکس با ناحیه‌های متحرک', 'layers' => 'لایه‌های جدا (هر لایه حرکت خودش)', 'video' => 'ویدیوی خودتان', 'slideshow' => 'اسلایدشوی چند عکس' ), 'regions' );
		$this->sw( 'fill', 'پر کردن کانتینر والد، پشت بقیهٔ ویجت‌ها', 'yes', array( 'prefix_class' => 'ay-fill-', 'description' => 'روشن: این ویجت پس‌زمینهٔ کانتینر می‌شود و متن و دکمه‌ها را به‌صورت ویجت‌های عادی روی آن می‌گذارید. خاموش: یک قاب مستقل با ارتفاع دلخواه.' ) );
		$this->cssvar( 'height', 'ارتفاع قاب', '--ay-hero-h', 20, 1200, 1, 70, array( 'vh', 'px' ), array( 'condition' => array( 'fill!' => 'yes' ) ) );
		$this->cssvar( 'fill_h', 'ارتفاع صحنه داخل کانتینر', '--ay-hero-fh', 10, 1200, 1, 100, array( '%', 'vh', 'px' ), array( 'condition' => array( 'fill' => 'yes' ), 'description' => 'در موبایل می‌توانید صحنه را فقط در بخش بالایی کانتینر نشان دهید تا متن زیر آن بیاید.' ) );
		$this->media( 'image', 'عکس', ay_asset( self::family_default( 'wide' ) ), array( 'condition' => array( 'mode' => array( 'regions', 'video' ) ), 'description' => 'در حالت ویدیو، این عکس تا بارگذاری ویدیو و وقتی حرکت خاموش است نمایش داده می‌شود. بهترین اندازه: ۳۸۴۰×۲۱۶۰ پیکسل.' ) );
		$this->media( 'image_tablet', 'عکس برای قاب‌های نزدیک به مربع (تبلت)', ay_asset( self::family_default( 'tablet' ) ), array( 'condition' => $regions, 'description' => 'اختیاری. نسبت پیشنهادی ۴:۳. هر جا شکل قاب به این عکس نزدیک‌تر باشد، همین نمایش داده می‌شود (نه بر اساس نام دستگاه).' ) );
		$this->media( 'image_mobile', 'عکس برای قاب‌های عمودی (موبایل)', ay_asset( self::family_default( 'mobile' ) ), array( 'condition' => $regions, 'description' => 'اختیاری. نسبت پیشنهادی حدود ۶:۱۳ (تمام‌قد گوشی).' ) );
		$safe = function ( $id, $label, $d ) use ( $regions ) {
			$this->add_control( $id, array( 'label' => $label, 'type' => CM::DIMENSIONS, 'size_units' => array( '%' ), 'allowed_dimensions' => 'all', 'default' => array( 'unit' => '%', 'top' => (string) $d[0], 'right' => (string) $d[1], 'bottom' => (string) $d[2], 'left' => (string) $d[3], 'isLinked' => false ), 'condition' => $regions ) );
		};
		$this->head( 'safe_h', 'بخشی که هرگز بریده نمی‌شود' );
		$this->note( 'safe_n', 'برای هر عکس بنویسید از هر لبه تا چند درصد می‌تواند بریده شود. آن‌چه می‌ماند (مثلاً خودِ گردنبند) در هر اندازهٔ صفحه کامل دیده می‌شود؛ اگر جا نشود عکس کمی کوچک‌تر نمایش داده می‌شود.' );
		$safe( 'safe', 'لبه‌های قابل برش · عکس اصلی', array( 2, 20, 8, 43 ) );
		$safe( 'safe_t', 'لبه‌های قابل برش · عکس تبلت', array( 2, 13, 11, 39 ) );
		$safe( 'safe_m', 'لبه‌های قابل برش · عکس موبایل', array( 10, 0, 41, 22 ) );
		$this->txt( 'alt', 'توضیح تصویر (برای صفحه‌خوان‌ها)', '', array( 'description' => 'اگر تصویر فقط تزئینی است خالی بگذارید.' ) );
		$this->add_responsive_control( 'focus_x', array( 'label' => 'نقطهٔ تمرکز افقی', 'type' => CM::SLIDER, 'range' => array( '%' => array( 'min' => 0, 'max' => 100 ) ), 'size_units' => array( '%' ), 'default' => array( 'unit' => '%', 'size' => 68 ), 'description' => 'وقتی قاب باریک‌تر از عکس است، این بخش از عکس در دید می‌ماند.' ) );
		$this->add_responsive_control( 'focus_y', array( 'label' => 'نقطهٔ تمرکز عمودی', 'type' => CM::SLIDER, 'range' => array( '%' => array( 'min' => 0, 'max' => 100 ) ), 'size_units' => array( '%' ), 'default' => array( 'unit' => '%', 'size' => 50 ) ) );
		$this->done();

		/* ---- motion (all modes) ---- */
		$this->sec( 's_motion', 'حرکت کلی' );
		$this->add_control( 'speed', array( 'label' => 'سرعت کلی', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 3, 'step' => 0.05 ) ), 'default' => array( 'size' => 1 ), 'description' => 'صفر یعنی تصویر کاملاً ثابت.' ) );
		$this->add_control( 'amp', array( 'label' => 'شدت کلی', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 3, 'step' => 0.05 ) ), 'default' => array( 'size' => 1 ) ) );
		$this->sw( 'mouse', 'واکنش به حرکت موس', 'yes' );
		$this->add_control( 'mouse_amt', array( 'label' => 'میزان واکنش به موس', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 3, 'step' => 0.05 ) ), 'default' => array( 'size' => 1 ), 'condition' => array( 'mouse' => 'yes' ) ) );
		$this->sw( 'motion_mobile', 'حرکت در موبایل', 'yes' );
		$this->sw( 'pause_off', 'توقف وقتی از دید خارج است', 'yes' );
		$this->done();

		/* ---- regions ---- */
		$this->sec( 's_regions', 'ناحیه‌های متحرک', false, $regions );
		$this->note( 'n_regions', 'هر ناحیه یک بیضی نرم روی عکس است که تاب می‌خورد، موج برمی‌دارد یا نفس می‌کشد. خود عکس تغییر نمی‌کند و با شدت صفر دقیقاً همان عکس است.' );
		$this->sw( 'outline', 'نمایش ناحیه‌ها در ویرایشگر', 'yes', array( 'description' => 'فقط هنگام ویرایش دیده می‌شود.' ) );
		$rep = new Repeater();
		$rep->add_control( 'label', array( 'label' => 'نام ناحیه', 'type' => CM::TEXT, 'default' => 'ناحیه' ) );
		$rep->add_control( 'for', array( 'label' => 'برای کدام عکس', 'type' => CM::SELECT, 'default' => 'wide', 'options' => array( 'wide' => 'عکس اصلی (عریض)', 'tablet' => 'عکس تبلت', 'mobile' => 'عکس موبایل' ) ) );
		$rep->add_control( 'on', array( 'label' => 'فعال', 'type' => CM::SWITCHER, 'label_on' => 'بله', 'label_off' => 'خیر', 'return_value' => 'yes', 'default' => 'yes' ) );
		$rep->add_control( 'type', array( 'label' => 'نوع حرکت', 'type' => CM::SELECT, 'default' => 'sway', 'options' => array( 'sway' => 'تاب خوردن دور یک نقطه', 'wave' => 'موج ریز', 'breathe' => 'نفس کشیدن' ) ) );
		$this->rs( $rep, 'x', 'مرکز افقی', 0, 100, 0.5, 50, '%' );
		$this->rs( $rep, 'y', 'مرکز عمودی', 0, 100, 0.5, 50, '%' );
		$this->rs( $rep, 'w', 'عرض ناحیه', 1, 150, 0.5, 20, '%' );
		$this->rs( $rep, 'h', 'ارتفاع ناحیه', 1, 150, 0.5, 20, '%' );
		$this->rs( $rep, 'feather', 'نرمی لبه', 1, 100, 1, 60 );
		$this->rs( $rep, 'amp', 'شدت', 0, 100, 1, 20 );
		$this->rs( $rep, 'speed', 'سرعت', 0, 3, 0.05, 0.5 );
		$this->rs( $rep, 'phase', 'جلو و عقب بودن نسبت به بقیه', 0, 6.28, 0.1, 0 );
		$this->rs( $rep, 'px', 'نقطهٔ ثابت افقی (محور تاب)', -20, 120, 0.5, 50, '%' );
		$this->rs( $rep, 'py', 'نقطهٔ ثابت عمودی (محور تاب)', -20, 120, 0.5, 100, '%' );
		$this->rs( $rep, 'depth', 'واکنش به موس', 0, 3, 0.1, 0.5 );
		$this->add_control( 'regions', array( 'label' => 'ناحیه‌ها (برای هر عکس حداکثر ۱۶)', 'type' => CM::REPEATER, 'fields' => $rep->get_controls(), 'default' => self::night_regions(), 'title_field' => '{{{ label }}}' ) );
		$this->done();

		$this->sec( 's_sparks', 'نقطه‌های درخشش', false, $regions );
		$this->sw( 'sparks_on', 'نمایش درخشش‌ها', 'yes' );
		$rep = new Repeater();
		$rep->add_control( 'for', array( 'label' => 'برای کدام عکس', 'type' => CM::SELECT, 'default' => 'wide', 'options' => array( 'wide' => 'عکس اصلی (عریض)', 'tablet' => 'عکس تبلت', 'mobile' => 'عکس موبایل' ) ) );
		$this->rs( $rep, 'x', 'جای افقی', 0, 100, 0.1, 50, '%' );
		$this->rs( $rep, 'y', 'جای عمودی', 0, 100, 0.1, 50, '%' );
		$this->rs( $rep, 'size', 'اندازه', 0.2, 5, 0.1, 1 );
		$this->rs( $rep, 'dur', 'مدت یک چشمک (ثانیه)', 1, 20, 0.1, 5 );
		$this->rs( $rep, 'delay', 'تأخیر (ثانیه)', 0, 20, 0.1, 0 );
		$this->add_control( 'sparks', array( 'label' => 'درخشش‌ها', 'type' => CM::REPEATER, 'fields' => $rep->get_controls(), 'default' => self::night_sparks(), 'title_field' => '{{{ for }}} · x: {{{ x.size }}} · y: {{{ y.size }}}', 'condition' => array( 'sparks_on' => 'yes' ) ) );
		$this->color( 'spark_color', 'رنگ درخشش', '--ay-spark', array( 'condition' => array( 'sparks_on' => 'yes' ) ) );
		$this->done();

		$this->sec( 's_floats', 'عناصر شناور', false, $regions );
		$this->sw( 'floats_on', 'نمایش عناصر شناور', 'yes' );
		$rep = new Repeater();
		$rep->add_control( 'image', array( 'label' => 'تصویر (PNG بدون پس‌زمینه)', 'type' => CM::MEDIA ) );
		$this->rs( $rep, 'x', 'شروع افقی', -20, 120, 0.5, 20, '%' );
		$this->rs( $rep, 'y', 'شروع عمودی', -20, 120, 0.5, 40, '%' );
		$this->rs( $rep, 'w', 'عرض', 0.5, 40, 0.5, 6, '%' );
		$this->rs( $rep, 'dx', 'مسیر افقی (درصد عرض عکس)', -150, 150, 1, 40 );
		$this->rs( $rep, 'dy', 'مسیر عمودی (درصد عرض عکس)', -150, 150, 1, -20 );
		$this->rs( $rep, 'rot', 'چرخش در طول مسیر (درجه)', -360, 360, 5, 45 );
		$this->rs( $rep, 'dur', 'مدت (ثانیه)', 4, 120, 1, 36 );
		$this->rs( $rep, 'delay', 'تأخیر (ثانیه)', 0, 120, 1, 0 );
		$this->rs( $rep, 'opacity', 'شفافیت', 0, 1, 0.05, 0.85 );
		$this->add_control( 'floats', array( 'label' => 'عناصر شناور', 'type' => CM::REPEATER, 'fields' => $rep->get_controls(), 'default' => self::night_floats(), 'title_field' => 'عنصر شناور', 'condition' => array( 'floats_on' => 'yes' ) ) );
		$this->done();

		/* ---- layers ---- */
		$this->sec( 's_layers', 'لایه‌ها', false, $layers );
		$this->note( 'n_layers', 'هر لایه یک تصویر بدون پس‌زمینه است. جای آن را با درصد نسبت به صحنه تعیین می‌کنید و برایش حرکت و عمق جدا می‌گذارید.' );
		$this->add_control( 'ratio', array( 'label' => 'نسبت صحنه (عرض ÷ ارتفاع)', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0.4, 'max' => 3, 'step' => 0.01 ) ), 'default' => array( 'size' => 1.78 ) ) );
		$rep = new Repeater();
		$rep->add_control( 'label', array( 'label' => 'نام لایه', 'type' => CM::TEXT, 'default' => 'لایه' ) );
		$rep->add_control( 'image', array( 'label' => 'تصویر', 'type' => CM::MEDIA ) );
		$this->rs( $rep, 'x', 'جای افقی (لبهٔ چپ)', -50, 150, 0.5, 30, '%' );
		$this->rs( $rep, 'y', 'جای عمودی (لبهٔ بالا)', -50, 150, 0.5, 20, '%' );
		$this->rs( $rep, 'w', 'عرض', 1, 200, 0.5, 30, '%' );
		$rep->add_control( 'motion', array( 'label' => 'حرکت', 'type' => CM::SELECT, 'default' => 'sway', 'options' => array( '' => 'ثابت', 'sway' => 'تاب خوردن', 'bob' => 'بالا و پایین رفتن', 'float' => 'شناور چرخان', 'drift' => 'عبور از صحنه', 'pulse' => 'تپش', 'twinkle' => 'چشمک' ) ) );
		$this->rs( $rep, 'amt', 'مقدار حرکت', 0, 100, 1, 12 );
		$this->rs( $rep, 'dur', 'مدت یک دور (ثانیه)', 0.5, 120, 0.5, 8 );
		$this->rs( $rep, 'delay', 'تأخیر (ثانیه)', 0, 60, 0.5, 0 );
		$this->rs( $rep, 'ox', 'محور افقی حرکت', 0, 100, 1, 50, '%' );
		$this->rs( $rep, 'oy', 'محور عمودی حرکت', 0, 100, 1, 50, '%' );
		$this->rs( $rep, 'depth', 'عمق (واکنش به موس)', 0, 60, 1, 12 );
		$this->rs( $rep, 'opacity', 'شفافیت', 0, 1, 0.05, 1 );
		$rep->add_control( 'z', array( 'label' => 'ترتیب لایه', 'type' => CM::NUMBER, 'default' => 1, 'min' => 0, 'max' => 99 ) );
		$rep->add_control( 'hide_mobile', array( 'label' => 'پنهان در موبایل', 'type' => CM::SWITCHER, 'label_on' => 'بله', 'label_off' => 'خیر', 'return_value' => 'yes', 'default' => '' ) );
		$this->add_control( 'layers', array( 'label' => 'لایه‌ها', 'type' => CM::REPEATER, 'fields' => $rep->get_controls(), 'default' => array(), 'title_field' => '{{{ label }}}' ) );
		$this->done();

		/* ---- video ---- */
		$this->sec( 's_video', 'ویدیو', false, $video );
		$this->add_control( 'video', array( 'label' => 'فایل ویدیو (MP4 یا WebM)', 'type' => CM::MEDIA, 'media_types' => array( 'video' ) ) );
		$this->add_control( 'video_mobile', array( 'label' => 'ویدیوی جدا برای موبایل (اختیاری)', 'type' => CM::MEDIA, 'media_types' => array( 'video' ) ) );
		$this->sw( 'v_loop', 'تکرار', 'yes' );
		$this->add_control( 'v_rate', array( 'label' => 'سرعت پخش', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0.25, 'max' => 2, 'step' => 0.05 ) ), 'default' => array( 'size' => 1 ) ) );
		$this->num( 'v_start', 'شروع از ثانیهٔ', 0, 0, 3600, 0.5 );
		$this->num( 'v_end', 'پایان در ثانیهٔ (۰ = تا آخر)', 0, 0, 3600, 0.5 );
		$this->sel( 'v_fit', 'جا شدن در قاب', array( 'cover' => 'پر کردن قاب (برش لبه‌ها)', 'contain' => 'نمایش کامل' ), 'cover' );
		$this->note( 'n_video', 'ویدیو بی‌صدا و خودکار پخش می‌شود (مرورگرها پخش خودکار با صدا را اجازه نمی‌دهند).' );
		$this->done();

		/* ---- slideshow ---- */
		$this->sec( 's_slides', 'اسلایدشو', false, $slides );
		$this->add_control( 'slides', array( 'label' => 'عکس‌ها', 'type' => CM::GALLERY ) );
		$this->num( 'sl_time', 'ماندن هر عکس (ثانیه)', 5, 1, 60, 0.5 );
		$this->num( 'sl_fade', 'مدت محو شدن (ثانیه)', 1.6, 0.2, 10, 0.1 );
		$this->add_control( 'sl_ken', array( 'label' => 'زوم آرام هر عکس', 'type' => CM::SLIDER, 'range' => array( 'px' => array( 'min' => 0, 'max' => 30, 'step' => 1 ) ), 'default' => array( 'size' => 8 ) ) );
		$this->sel( 'sl_order', 'ترتیب', array( 'seq' => 'به ترتیب', 'rand' => 'تصادفی' ), 'seq' );
		$this->done();

		/* ---- style ---- */
		$this->sec( 'st_veil', 'پوشش روی تصویر', true );
		$this->sel( 'veil', 'سایهٔ خوانایی متن', array( '' => 'بدون سایه', 'left' => 'از چپ', 'right' => 'از راست', 'bottom' => 'از پایین', 'top' => 'از بالا', 'full' => 'روی کل تصویر' ), 'left', array( 'prefix_class' => 'ay-veil-' ) );
		$this->color( 'veil_color', 'رنگ سایه', '--ay-veil', array( 'condition' => array( 'veil!' => '' ) ) );
		$this->cssvar( 'veil_op', 'شدت سایه', '--ay-veil-op', 0, 1, 0.02, 0.84, '', array( 'condition' => array( 'veil!' => '' ) ), false );
		$this->cssvar( 'veil_size', 'گسترهٔ سایه', '--ay-veil-size', 10, 100, 1, 54, '%', array( 'condition' => array( 'veil!' => array( '', 'full' ) ) ) );
		$this->sw( 'fade', 'محو شدن پایین به رنگ صفحه', 'yes', array( 'prefix_class' => 'ay-fade-', 'separator' => 'before' ) );
		$this->color( 'fade_color', 'رنگ محو شدن', '--ay-fade', array( 'condition' => array( 'fade' => 'yes' ) ) );
		$this->cssvar( 'fade_size', 'ارتفاع محو شدن', '--ay-fade-size', 0, 60, 1, 18, '%', array( 'condition' => array( 'fade' => 'yes' ) ) );
		$this->done();

		$this->sec( 'st_media', 'تصویر', true );
		$this->filters( 'media_filters', 'فیلترهای تصویر', '.ay-hs-stage, {{WRAPPER}} .ay-hero-media' );
		$this->cssvar( 'media_op', 'شفافیت تصویر', '--ay-hero-op', 0, 1, 0.02, null, '', array(), false );
		$this->add_responsive_control( 'radius', array( 'label' => 'گردی گوشه‌ها', 'type' => CM::DIMENSIONS, 'size_units' => array( 'px', '%' ), 'selectors' => array( '{{WRAPPER}} .ay-hero' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ) ) );
		$this->color( 'bg', 'رنگ پشت تصویر', array( '.ay-hero' => 'background-color' ) );
		$this->done();
	}

	private function pct( $v, $default ) {
		return ( is_array( $v ) && isset( $v['size'] ) && '' !== $v['size'] ) ? (float) $v['size'] : $default;
	}

	private function media_dims( $media ) {
		$id = isset( $media['id'] ) ? absint( $media['id'] ) : 0;
		if ( $id ) {
			$meta = wp_get_attachment_metadata( $id );
			if ( ! empty( $meta['width'] ) && ! empty( $meta['height'] ) ) {
				return array( (int) $meta['width'], (int) $meta['height'] );
			}
		}
		foreach ( self::families() as $files ) {
			foreach ( $files as $f ) {
				if ( ! empty( $media['url'] ) && false !== strpos( $media['url'], $f[0] ) ) {
					return array( $f[1], $f[2] );
				}
			}
		}
		if ( ! empty( $media['url'] ) && false !== strpos( $media['url'], 'night-garden' ) ) {
			return array( 1672, 941 );
		}
		return array( 0, 0 );
	}

	protected function render() {
		$s    = $this->get_settings_for_display();
		$mode = in_array( $s['mode'], array( 'regions', 'layers', 'video', 'slideshow' ), true ) ? $s['mode'] : 'regions';
		$url  = isset( $s['image']['url'] ) ? $s['image']['url'] : '';
		$edit = $this->in_editor();
		$f    = function ( $key, $def ) use ( $s ) {
			return array( $this->pct( $s[ $key ], $def ) / 100, $this->pct( isset( $s[ $key . '_tablet' ] ) ? $s[ $key . '_tablet' ] : null, -1 ) / 100, $this->pct( isset( $s[ $key . '_mobile' ] ) ? $s[ $key . '_mobile' ] : null, -1 ) / 100 );
		};
		$cfg = array(
			'mode'     => $mode,
			'alt'      => (string) $s['alt'],
			'fx'       => $f( 'focus_x', 68 ),
			'fy'       => $f( 'focus_y', 50 ),
			'speed'    => $this->pct( $s['speed'], 1 ),
			'amp'      => $this->pct( $s['amp'], 1 ),
			'mouse'    => 'yes' === $s['mouse'],
			'mouseAmt' => 0.006 * $this->pct( $s['mouse_amt'], 1 ),
			'mobile'   => 'yes' === $s['motion_mobile'],
			'pauseOff' => 'yes' === $s['pause_off'],
		);

		if ( 'regions' === $mode ) {
			if ( ! $url ) {
				$this->empty_note( 'یک عکس برای صحنهٔ هیرو انتخاب کنید.' );
				return;
			}
			$cfg['outline']  = $edit && 'yes' === $s['outline'];
			$cfg['variants'] = array();
			$factor          = array( 'sway' => 0.0005, 'wave' => 0.0001, 'breathe' => 0.0005 );
			foreach ( array( 'wide' => array( 'image', 'safe' ), 'tablet' => array( 'image_tablet', 'safe_t' ), 'mobile' => array( 'image_mobile', 'safe_m' ) ) as $key => $ids ) {
				$src = $this->variant_source( isset( $s[ $ids[0] ] ) ? $s[ $ids[0] ] : array() );
				if ( ! $src ) {
					continue;
				}
				if ( 'wide' === $key ) {
					$own = empty( $src[3] );
				} elseif ( ! empty( $own ) && ! empty( $src[3] ) ) {
					continue;   /* the owner's own main picture is not mixed with the bundled tablet / phone pictures */
				}
				$sf   = isset( $s[ $ids[1] ] ) && is_array( $s[ $ids[1] ] ) ? $s[ $ids[1] ] : array();
				$safe = array();
				foreach ( array( 'top', 'right', 'bottom', 'left' ) as $side ) {
					$safe[] = isset( $sf[ $side ] ) && is_numeric( $sf[ $side ] ) ? max( 0, min( 49, (float) $sf[ $side ] ) ) / 100 : 0;
				}
				$v = array( 'k' => $key, 'set' => $src[0], 'w' => (int) $src[1], 'h' => (int) $src[2], 'safe' => $safe, 'regions' => array(), 'sparks' => array() );
				foreach ( (array) $s['regions'] as $r ) {
					if ( 'yes' !== ( isset( $r['on'] ) ? $r['on'] : 'yes' ) || ( isset( $r['for'] ) && '' !== $r['for'] ? $r['for'] : 'wide' ) !== $key || count( $v['regions'] ) >= 16 ) {
						continue;
					}
					$type           = isset( $factor[ $r['type'] ] ) ? $r['type'] : 'sway';
					$v['regions'][] = array(
						'x'     => $this->pct( $r['x'], 50 ) / 100,
						'y'     => $this->pct( $r['y'], 50 ) / 100,
						'rx'    => $this->pct( $r['w'], 20 ) / 200,
						'ry'    => $this->pct( $r['h'], 20 ) / 200,
						'f'     => $this->pct( $r['feather'], 60 ) / 100,
						'type'  => $type,
						'amp'   => $this->pct( $r['amp'], 20 ) * $factor[ $type ],
						'speed' => $this->pct( $r['speed'], 0.5 ),
						'phase' => $this->pct( $r['phase'], 0 ),
						'px'    => $this->pct( $r['px'], 50 ) / 100,
						'py'    => $this->pct( $r['py'], 100 ) / 100,
						'depth' => $this->pct( $r['depth'], 0.5 ),
					);
				}
				if ( 'yes' === $s['sparks_on'] ) {
					foreach ( (array) $s['sparks'] as $p ) {
						if ( ( isset( $p['for'] ) && '' !== $p['for'] ? $p['for'] : 'wide' ) === $key ) {
							$v['sparks'][] = array( 'x' => $this->pct( $p['x'], 50 ) / 100, 'y' => $this->pct( $p['y'], 50 ) / 100, 's' => $this->pct( $p['size'], 1 ), 'dur' => $this->pct( $p['dur'], 5 ), 'dl' => $this->pct( $p['delay'], 0 ) );
						}
					}
				}
				$cfg['variants'][] = $v;
			}
			$cfg['img'] = $url;
			$cfg['floats'] = array();
			if ( 'yes' === $s['floats_on'] ) {
				foreach ( (array) $s['floats'] as $p ) {
					if ( empty( $p['image']['url'] ) ) {
						continue;
					}
					$cfg['floats'][] = array( 'src' => esc_url_raw( $p['image']['url'] ), 'x' => $this->pct( $p['x'], 20 ), 'y' => $this->pct( $p['y'], 40 ), 'w' => $this->pct( $p['w'], 6 ), 'dx' => $this->pct( $p['dx'], 40 ), 'dy' => $this->pct( $p['dy'], -20 ), 'rot' => $this->pct( $p['rot'], 45 ), 'dur' => $this->pct( $p['dur'], 36 ), 'dl' => $this->pct( $p['delay'], 0 ), 'o' => $this->pct( $p['opacity'], 0.85 ) );
				}
			}
		} elseif ( 'layers' === $mode ) {
			$cfg['ratio']  = max( 0.2, $this->pct( $s['ratio'], 1.78 ) );
			$cfg['layers'] = array();
			foreach ( (array) $s['layers'] as $l ) {
				if ( empty( $l['image']['url'] ) ) {
					continue;
				}
				$cfg['layers'][] = array( 'src' => esc_url_raw( $l['image']['url'] ), 'x' => $this->pct( $l['x'], 30 ), 'y' => $this->pct( $l['y'], 20 ), 'w' => $this->pct( $l['w'], 30 ), 'motion' => (string) $l['motion'], 'amt' => $this->pct( $l['amt'], 12 ), 'dur' => $this->pct( $l['dur'], 8 ), 'dl' => $this->pct( $l['delay'], 0 ), 'ox' => $this->pct( $l['ox'], 50 ), 'oy' => $this->pct( $l['oy'], 50 ), 'depth' => $this->pct( $l['depth'], 12 ), 'o' => $this->pct( $l['opacity'], 1 ), 'z' => isset( $l['z'] ) ? (int) $l['z'] : 1, 'hm' => isset( $l['hide_mobile'] ) && 'yes' === $l['hide_mobile'] );
			}
			if ( ! $cfg['layers'] ) {
				$this->empty_note( 'در بخش «لایه‌ها» دست‌کم یک تصویر اضافه کنید.' );
				return;
			}
		} elseif ( 'video' === $mode ) {
			$cfg['img']   = $url;
			$cfg['video'] = array(
				'src'    => isset( $s['video']['url'] ) ? esc_url_raw( $s['video']['url'] ) : '',
				'mobile' => isset( $s['video_mobile']['url'] ) ? esc_url_raw( $s['video_mobile']['url'] ) : '',
				'loop'   => 'yes' === $s['v_loop'],
				'rate'   => $this->pct( $s['v_rate'], 1 ),
				'start'  => (float) $s['v_start'],
				'end'    => (float) $s['v_end'],
				'fit'    => 'contain' === $s['v_fit'] ? 'contain' : 'cover',
			);
			if ( ! $cfg['video']['src'] && ! $url ) {
				$this->empty_note( 'ویدیوی خود را در بخش «ویدیو» انتخاب کنید. تا آن زمان عکس جایگزین نمایش داده می‌شود.' );
				return;
			}
		} else {
			$cfg['slides'] = array();
			foreach ( (array) $s['slides'] as $g ) {
				$u = ! empty( $g['id'] ) ? wp_get_attachment_image_url( absint( $g['id'] ), 'full' ) : ( isset( $g['url'] ) ? $g['url'] : '' );
				if ( $u ) {
					$cfg['slides'][] = esc_url_raw( $u );
				}
			}
			$cfg['time'] = max( 1, (float) $s['sl_time'] );
			$cfg['fade'] = max( 0.2, (float) $s['sl_fade'] );
			$cfg['ken']  = $this->pct( $s['sl_ken'], 8 ) / 100;
			$cfg['rand'] = 'rand' === $s['sl_order'];
			if ( ! $cfg['slides'] ) {
				$this->empty_note( 'در بخش «اسلایدشو» چند عکس انتخاب کنید.' );
				return;
			}
		}

		echo '<div class="ay-hero ay-hs ay-hero-' . esc_attr( $mode ) . '" data-ay-hero="' . esc_attr( wp_json_encode( $cfg ) ) . '">';
		if ( 'regions' === $mode && ! empty( $cfg['variants'] ) ) {
			/* the picture that suits this frame is chosen before anything is downloaded */
			echo '<img class="ay-hs-img ay-hero-media"' . ( $edit ? ' src="' . esc_url( $cfg['variants'][0]['set'][0][0] ) . '"' : '' ) . ' alt="' . esc_attr( $s['alt'] ) . '" decoding="async" fetchpriority="high">';
			echo '<noscript><img class="ay-hs-img ay-hero-media" src="' . esc_url( $url ) . '" alt="' . esc_attr( $s['alt'] ) . '"></noscript>';
			echo "<script>(function(){var s=document.currentScript,r=s&&s.parentNode;if(!r)return;try{var c=JSON.parse(r.getAttribute('data-ay-hero')),W=r.clientWidth,H=r.clientHeight||1,a=W/H,b=0,d=1e9;c.variants.forEach(function(v,i){var q=Math.abs(Math.log(a/(v.w/v.h)))+(v.k==='tablet'?.15:0);if(q<d){d=q;b=i}});var v=c.variants[b],n=Math.max(W/v.w,H/v.h)*v.w*Math.min(window.devicePixelRatio||1,2),u=v.set[v.set.length-1][0];for(var i=0;i<v.set.length;i++){if(v.set[i][1]>=n){u=v.set[i][0];break}}r.setAttribute('data-v',b);r.querySelector('img').src=u}catch(e){}})();</script>";
		} elseif ( in_array( $mode, array( 'regions', 'video' ), true ) && $url ) {
			echo '<img class="ay-hs-img ay-hero-media" src="' . esc_url( $url ) . '" alt="' . esc_attr( $s['alt'] ) . '" decoding="async" fetchpriority="high">';
		}
		echo '<span class="ay-hero-veil" aria-hidden="true"></span><span class="ay-hero-fade" aria-hidden="true"></span></div>';
		if ( $edit && $this->pct( $s['speed'], 1 ) <= 0 ) {
			echo '<div class="ay-empty ay-empty-float" dir="rtl">سرعت کلی صفر است؛ تصویر ثابت نمایش داده می‌شود.</div>';
		}
	}
}
